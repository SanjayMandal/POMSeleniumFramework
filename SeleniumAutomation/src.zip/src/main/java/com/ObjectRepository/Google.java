package com.ObjectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resources.FunctionalLibrary;





public class Google {
	
	@FindBy(xpath="//*[@id='lst-ib']")
	private WebElement txtSearchBox;
	
	/**
	 * Constructor to instantiate the page elements
	 */
	public Google() {
		PageFactory.initElements(FunctionalLibrary.driver, this);
	}
	
	//getter methods to access elements
	
	public WebElement getTxtSearchBox() {
		return txtSearchBox;
	}


}
