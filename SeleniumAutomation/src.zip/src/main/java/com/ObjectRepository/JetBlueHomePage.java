package com.ObjectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resources.FunctionalLibrary;

public class JetBlueHomePage {

	@FindBy(xpath = "//span[contains(text(),'Sign In')]")
	private WebElement lnkSignIn;
	
	@FindBy(xpath = "//span[contains(text(),'Sign Out')]")
	private WebElement lnkSignOut;
	
	@FindBy(xpath = "//a[@class='travel-information jb-primary-link']")
	private WebElement lnkTravelInformation;
	
	/**
	 * Constructor to instantiate the page elements
	 */
	public JetBlueHomePage() {
		PageFactory.initElements(FunctionalLibrary.driver, this);
	}
	
	//getter methods to access elements
	public WebElement getSignInLink() {
		return lnkSignIn;
	}
	
	public WebElement getSignOutLink() {
		return lnkSignOut;
	}
	
	public WebElement getTravelInformationLink() {
		return lnkTravelInformation;
	}
}
