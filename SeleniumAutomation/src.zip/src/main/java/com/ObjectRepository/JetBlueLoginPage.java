package com.ObjectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resources.FunctionalLibrary;

public class JetBlueLoginPage {
	
	@FindBy(id="username")
	private WebElement txtUserName;
	
	@FindBy(id="password")
	private WebElement txtPassword;
	
	@FindBy(xpath="//button[contains(text(),'Sign In')]")
	private WebElement btnSignIn;
	
	/**
	 * Constructor to instantiate the page elements
	 */
	public JetBlueLoginPage() {
		PageFactory.initElements(FunctionalLibrary.driver, this);
	}
	
	//getter methods to access elements
	public WebElement getUserNameTextField() {
		return txtUserName;
	}
	
	public WebElement getPasswordTextField() {
		return txtPassword;
	}
	
	public WebElement getSignInButton() {
		return btnSignIn;
	}
}
