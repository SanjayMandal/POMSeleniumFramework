package com.ObjectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resources.FunctionalLibrary;

public class Oracle_Fusion_HomePage {

	@FindBy(xpath = "//*[@id='pt1:_UISmmLink::icon']")
	private WebElement lnkNavigator;
	
	@FindBy(xpath = "//*[@id='pt1:nv_itemNode_workforce_management_person_management']")
	private WebElement lnkPersonManagement;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt1:0:pt1:Perso1:0:SP3:q1:value10::content']")
	private WebElement txtPersonNum;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt1:0:pt1:Perso1:0:SP3:q1:value40::content']")
	private WebElement CheckBox;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt1:0:pt1:Perso1:0:SP3:q1::search']")
	private WebElement btnSearch;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt1:0:pt1:Perso1:0:SP3:table1:_ATp:table2:0:gl1']")
	private WebElement lnkPersonNameListedUnderSearchResults;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt1:0:pt1:Manag1:0:AP1:SPph::_afrTtxt']/div/h1")
	private WebElement verifyManageemployepage;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:_FOTsdiHcmIntWaTasksId::icon']")
	private WebElement lnkTasks;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:_FOTRaT:0:RAtl19']")
	private WebElement lnkCreateWorkRelationship;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:0:pt1:SP1:SPph::_afrTtxt']/div/h1")
	private WebElement verifyCreateWorkRelationshipPage;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:0:pt1:SP1:inputDate1::content']")
	private WebElement txtStartDate;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:0:pt1:SP1:action::content']")
	private WebElement chooseAction;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:0:pt1:SP1:soc1::content']")
	private WebElement chooseActionreason;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:0:pt1:SP1:NewPe1:0:pt_r1:0:r1:0:i1:6:it2::content']")
	private WebElement txtPANNumber;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:0:pt1:SP1:NewPe1:0:pt_r1:0:df1_PersonDFFIteratordiveDepth__FLEX_EMPTY::content']")
	private WebElement txtDiveDepth;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:0:pt1:SP1:tt1:next']/a")
	private WebElement lnkNext;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:1:pt1:SP1:SPph::_afrTtxt']/div/h1")
	private WebElement verifyPersonInformationPage;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:1:pt1:SP1:Perso1:0:Perso1:0:r1:0:i1:4:inputComboboxListOfValues28::content']")
	private WebElement txtPinCode;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:1:pt1:SP1:Perso1:0:Perso1:0:r1:0:i1:5:inputComboboxListOfValues25::content']")
	private WebElement txtState;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:1:pt1:SP1:tt1:next']/a")
	private WebElement lnkNext1;
	
	@FindBy(xpath = "[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:2:pt2:SP1:SPph::_afrTtxt']/div/h1")
	private WebElement verifyEmployeeInformationPage;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:2:pt2:SP1:AddWo2:0:AddWo1:0:businessUnitId::lovIconId']")
	private WebElement dropdownbtnBusinessUnit;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:2:pt2:SP1:AddWo2:0:AddWo1:0:businessUnitId::dropdownPopup::dropDownContent::db']/table/tbody/tr[1]/td")
	private WebElement selectBusinessUnitfromDropDown;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:2:pt2:SP1:AddWo2:0:JobDe1:0:df2_BaseWorkerAsgDFFIterator__FLEX_Context__FLEX_EMPTY::content']")
	private WebElement valueInOfficerField;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:2:pt2:SP1:tt1:next']/a")
	private WebElement lnkNext2;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:3:pt1:SP2:SPph::_afrTtxt']/div/h1")
	private WebElement verifyCompensationAndOtherInformationPage;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:3:pt1:SP2:tt1:next']/a")
	private WebElement lnkNext3;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:4:pt1:SP3:SPph::_afrTtxt']/div/h1")
	private WebElement verifyReviewPage;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:4:pt1:SP3:tt1:save']/table/tbody/tr/td[1]/a")
	private WebElement clickSave;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FOSritemNode_workforce_management_person_management:0:MAt2:1:pt1:r1:4:pt1:SP3:tt1:okConfirmationDialog']")
	private WebElement clickSaveOK;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:4:pt1:SP3:tt1:submit']/a")
	private WebElement clickSubmit;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FONSr2:0:MAt2:1:pt1:r1:4:pt1:SP3:tt1:okWarningDialog']")
	private WebElement clickSubmitYes;
	
	@FindBy(xpath = "//*[@id='_FOpt1:_FOr1:0:_FOSritemNode_workforce_management_person_management:0:MAt2:1:pt1:r1:4:pt1:SP3:tt1:okConfirmationDialog']")
	private WebElement clickSubmitOK;
	
	/**
	 * Constructor to instantiate the page elements
	 */
	public Oracle_Fusion_HomePage() {
		PageFactory.initElements(FunctionalLibrary.driver, this);
	}

	//getter methods to access elements
	
	public WebElement getLnkNavigator() {
		return lnkNavigator;
	}

	public WebElement getLnkPersonManagement() {
		return lnkPersonManagement;
	}

	public WebElement getTxtPersonNum() {
		return txtPersonNum;
	}

	public WebElement getCheckBox() {
		return CheckBox;
	}

	public WebElement getBtnSearch() {
		return btnSearch;
	}

	public WebElement getLnkPersonNameListedUnderSearchResults() {
		return lnkPersonNameListedUnderSearchResults;
	}

	public WebElement getVerifyManageemployepage() {
		return verifyManageemployepage;
	}

	public WebElement getLnkTasks() {
		return lnkTasks;
	}

	public WebElement getLnkCreateWorkRelationship() {
		return lnkCreateWorkRelationship;
	}

	public WebElement getVerifyCreateWorkRelationshipPage() {
		return verifyCreateWorkRelationshipPage;
	}

	public WebElement getTxtStartDate() {
		return txtStartDate;
	}

	public WebElement getChooseAction() {
		return chooseAction;
	}

	public WebElement getChooseActionreason() {
		return chooseActionreason;
	}
	public WebElement getTxtPANNumber() {
		return txtPANNumber;
	}
	public WebElement getTxtDiveDepth() {
		return txtDiveDepth;
	}

	public WebElement getLnkNext() {
		return lnkNext;
	}

	public WebElement getVerifyPersonInformationPage() {
		return verifyPersonInformationPage;
	}
	
	public WebElement getTxtPinCode() {
		return txtPinCode;
	}
	
	public WebElement getTxtState() {
		return txtState;
	}

	public WebElement getLnkNext1() {
		return lnkNext1;
	}

	public WebElement getVerifyEmployeeInformationPage() {
		return verifyEmployeeInformationPage;
	}

	public WebElement getDropdownbtnBusinessUnit() {
		return dropdownbtnBusinessUnit;
	}

	public WebElement getSelectBusinessUnitfromDropDown() {
		return selectBusinessUnitfromDropDown;
	}

	public WebElement getValueInOfficerField() {
		return valueInOfficerField;
	}

	public WebElement getLnkNext2() {
		return lnkNext2;
	}

	public WebElement getVerifyCompensationAndOtherInformationPage() {
		return verifyCompensationAndOtherInformationPage;
	}

	public WebElement getLnkNext3() {
		return lnkNext3;
	}

	public WebElement getVerifyReviewPage() {
		return verifyReviewPage;
	}

	public WebElement getClickSave() {
		return clickSave;
	}

	public WebElement getClickSaveOK() {
		return clickSaveOK;
	}

	public WebElement getClickSubmit() {
		return clickSubmit;
	}

	public WebElement getClickSubmitYes() {
		return clickSubmitYes;
	}

	public WebElement getClickSubmitOK() {
		return clickSubmitOK;
	}
	
	
}
