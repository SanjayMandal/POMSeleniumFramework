package com.ObjectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.resources.FunctionalLibrary;

public class Oracle_Fusion_LoginPage {
	
	@FindBy(xpath="//*[@id='userid']")
	private WebElement txtUserName;
	
	@FindBy(xpath="//*[@id='password']")
	private WebElement txtPassword;
	
	@FindBy(xpath="//*[@id='btnActive']")
	private WebElement btnSignIn;
	
	/**
	 * Constructor to instantiate the page elements
	 */
	public Oracle_Fusion_LoginPage() {
		PageFactory.initElements(FunctionalLibrary.driver, this);
	}
	
	//getter methods to access elements
	public WebElement getUserNameTextField() {
		return txtUserName;
	}
	
	public WebElement getPasswordTextField() {
		return txtPassword;
	}
	
	public WebElement getSignInButton() {
		return btnSignIn;
	}
}
