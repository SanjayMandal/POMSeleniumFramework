package com.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;

import com.resources.FunctionalLibrary;
import com.resources.GetdatafromExcel;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleSteps {
	private Scenario scenario;

	@Before
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	    
	}
	@Given("^I am in google home page$")
	public void i_am_in_google_home_page() throws Throwable {
		FunctionalLibrary.driver.get("https://www.google.co.in");
	}

	@When("^I search for \"([^\"]*)\"$")
	public void i_search_for(String arg1) throws Throwable {
		System.out.println(arg1);
		String text=GetdatafromExcel.getData(scenario.getName(), arg1);
		System.out.println("output from excel"+text);
		FunctionalLibrary.driver.findElement(By.id("lst-ib")).sendKeys(text,Keys.ENTER);
	}

	@Then("^I verify the \"([^\"]*)\" in search result$")
	public void i_verify_the_in_search_result(String arg1) throws Throwable {
		System.out.println(arg1);
		System.out.println(scenario.getName());
		Assert.assertTrue(FunctionalLibrary.driver.getPageSource().contains(arg1));
	}
	
}
