package com.stepdefinition;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.ObjectRepository.Google;
import com.resources.FunctionalLibrary;
import com.resources.GetdatafromExcel;

import cucumber.api.Scenario;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class GoogleSteps1 extends FunctionalLibrary {
	private static Google text = null;
	private Scenario scenario;
	
	@BeforeClass
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	 }
	
	@Given("^user is in google home page$")
	public void user_is_in_google_home_page() {
		navigateToUrl("https://www.google.co.in");
	}

	@When("^user searches for \"([^\"]*)\"$")
	public void user_searches_for(String data){
		text = new Google();
		System.out.println(data);
		String ag1=GetdatafromExcel.getData(scenario.getName(), data);
		System.out.println("output from excel"+ag1);
		setText(text.getTxtSearchBox(),ag1);
	}

	@Then("^user verifies the \"([^\"]*)\" in search result$")
	public void user_verifies_the_in_search_result(String arg1) {
		System.out.println(arg1);
		System.out.println(scenario.getName());
		Assert.assertTrue(text.getTxtSearchBox().getText().contains(arg1));
	}

	
	
}
