package com.stepdefinition;

import org.testng.Assert;

import com.ObjectRepository.Oracle_Fusion_HomePage;
import com.ObjectRepository.Oracle_Fusion_LoginPage;
import com.resources.FunctionalLibrary;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Oracle_Fusion_StepDefinition extends FunctionalLibrary {
	
	private static Oracle_Fusion_HomePage home = null;
	private static Oracle_Fusion_LoginPage login = null;
	private Scenario scenario;
	
	@Before
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	}
	
	@Given("^User is on Oracle Fusion application homepage$")
	public void user_is_on_Oracle_Fusion_application_homepage() throws Throwable {
	    navigateToUrl("https://bes.hcm.ap2.oraclecloud.com/hcmCore/faces/FuseWelcome?");

	    
	}

	@When("^Enter the credentials \"([^\"]*)\" & \"([^\"]*)\"$")
	public void giving_credentials_as_and(String userid, String password) throws Throwable {
		home = new Oracle_Fusion_HomePage();
		login = new Oracle_Fusion_LoginPage();
		Thread.sleep(10000);
		//Reports.logStep(LogStatus.INFO, "Waiting for 10 secs", "Waited successfully", false);
		setText(login.getUserNameTextField(),userid);
		Thread.sleep(1000);
		//String ag1=GetdatafromExcel.getData(scenario.getName(), password);
		setText(login.getPasswordTextField(),password);
		Thread.sleep(1000);
		//Reports.logStep(LogStatus.INFO, "Taking Screenshot", "Screenshot has been taken successfully", true);
		
	}
	
	@When("^Click on Sign In button$")
	public void click_on_Sign_In_button() throws Throwable {
		click(login.getSignInButton());
		Thread.sleep(10000);
		//Reports.logStep(LogStatus.INFO, "Waiting for 10 secs", "Waited successfully", false);
		//Reports.logStep(LogStatus.INFO, "Taking Screenshot", "Screenshot has been taken successfully", true);
	}
	
	@Then("^User should be logged In$")
	public void user_should_be_logged_in() throws Throwable {
		//waitForElementVisibility(home.getLnkNavigator());
		Assert.assertTrue(home.getLnkNavigator().isDisplayed());
	}
	
	@When("^Click on Navigator Icon$")
	public void click_on_Navigator_Icon() throws Throwable {
	    click(home.getLnkNavigator());
	    Thread.sleep(5000);
	    //Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	}
	
	@When("^Click on Person Management under My Workforce$")
	public void click_on_Person_Management_under_My_Workforce() throws Throwable {
	    click(home.getLnkPersonManagement());
	    Thread.sleep(5000);
	   // Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	   // Reports.logStep(LogStatus.INFO, "Taking Screenshot", "Screenshot has been taken successfully", true);
	}
	
	@When("^Enter Person Number \"([^\"]*)\" in the Number Field of the Terminated employee & click on Search$")
	public void enter_Employee_Name_in_the_Name_Field_of_the_Terminated_employee_click_on_Search(String PesronNum) throws Throwable {
	    setText(home.getTxtPersonNum(), PesronNum);
	    Thread.sleep(3000);
	    click(home.getCheckBox());
	    Thread.sleep(3000);
	    click(home.getBtnSearch());
	    Thread.sleep(5000);
	    //Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	}
	
	@When("^User should see employee listed under Search Results and click on employe name$")
	public void user_should_see_employee_listed_under_Search_Results_and_click_on_employe_name() throws Throwable {
	    click(home.getLnkPersonNameListedUnderSearchResults());
	    Thread.sleep(5000);
	   // Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	}

	@Then("^User should see the Manage Employment page and verify the same\\.$")
	public void user_should_see_the_Manage_Employment_page_and_verify_the_same() throws Throwable {
		//waitForElementVisibility(home.getVerifyManageemployepage());
		Assert.assertTrue(home.getVerifyManageemployepage().isDisplayed());
	}

	@When("^Click on Tasks and again on Create Work Relationship$")
	public void click_on_Tasks_and_again_on_Create_Work_Relationship() throws Throwable {
	    click(home.getLnkTasks());
	    Thread.sleep(5000);
	   // Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	    click(home.getLnkCreateWorkRelationship());
	    Thread.sleep(5000);
	   // Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	}

	@Then("^User should see Create Work Relationship page$")
	public void user_should_see_Create_Work_Relationship_page() throws Throwable {
		//waitForElementVisibility(home.getVerifyCreateWorkRelationshipPage());
		Assert.assertTrue(home.getVerifyCreateWorkRelationshipPage().isDisplayed());
	}

	@When("^Enter the Start Date \"([^\"]*)\" and choose Action \"([^\"]*)\",Action Reason \"([^\"]*)\" and give the in Dive Depth \"([^\"]*)\" field$")
	public void enter_the_Start_Date_and_choose_Action_and_give_the_in_Dive_Depth_field(String StartDate, String ChooseAction, String ChooseActionReason, String DiveDepth) throws Throwable {
	   setText(home.getTxtStartDate(),StartDate);
	   Thread.sleep(3000);
	   selectByText(home.getChooseAction(), ChooseAction);
	   Thread.sleep(7000);
	  // Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	   selectByText(home.getChooseActionreason(), ChooseActionReason);
	   Thread.sleep(3000);
	   //setText(home.getTxtPANNumber(), "NHL4256R");
	   setText(home.getTxtDiveDepth(),DiveDepth);
	}

	@When("^Click on Next$")
	public void click_on_Next() throws Throwable {
		click(home.getLnkNext());
		Thread.sleep(5000);
		//Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	    
	}

	@Then("^User should see Create Work Relationship: Person Information page$")
	public void user_should_see_Create_Work_Relationship_Person_Information_page() throws Throwable {
		//waitForElementVisibility(home.getVerifyPersonInformationPage());
		//Assert.assertTrue(home.getVerifyPersonInformationPage().isDisplayed());
		//setText(home.getTxtPinCode(),"603103");
		Thread.sleep(5000);
		//Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
		//setText(home.getTxtState(),"Tamil Nadu");
	}

	@When("^Again click on Next1$")
	public void again_click_on_Next1() throws Throwable {
		click(home.getLnkNext1());
		Thread.sleep(5000);
		//Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	}

	@Then("^User should see Create Work Relationship: Employment Information page$")
	public void user_should_see_Create_Work_Relationship_Employment_Information_page() throws Throwable {
		//waitForElementVisibility(home.getVerifyEmployeeInformationPage());
		//Assert.assertTrue(home.getVerifyEmployeeInformationPage().isDisplayed());
	}

	@When("^Select Business Unit and choose Officer field \"([^\"]*)\"$")
	public void select_Business_Unit_and_choose_Officer_field(String Value) throws Throwable {
	   // click(home.getDropdownbtnBusinessUnit());
	    Thread.sleep(7000);
	   // Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	    click(home.getSelectBusinessUnitfromDropDown());
	    Thread.sleep(7000);
	   // Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	    selectByValue(home.getValueInOfficerField(), Value);
	    
	}
	
	@When("^Click on Next2$")
	public void again_I_click_on_Next2() throws Throwable {
		click(home.getLnkNext2());
		Thread.sleep(5000);
		//Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	}
	@Then("^User should see Create Work Relationship: Compensation and Other Information page$")
	public void user_should_see_Create_Work_Relationship_Compensation_and_Other_Information_page() throws Throwable {
		//waitForElementVisibility(home.getVerifyCompensationAndOtherInformationPage());
		//Assert.assertTrue(home.getVerifyCompensationAndOtherInformationPage().isDisplayed());
	}

	@When("^Again click on Next3$")
	public void again_click_on_Next3() throws Throwable {
		click(home.getLnkNext3());
		Thread.sleep(5000);
		//Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	}

	@Then("^User should see Create Work Relationship: Review page$")
	public void user_should_see_Create_Work_Relationship_Review_page() throws Throwable {
		//waitForElementVisibility(home.getVerifyReviewPage());
		//Assert.assertTrue(home.getVerifyReviewPage().isDisplayed());
	}

	@When("^Click on Save button$")
	public void click_on_Save_button() throws Throwable {
	    click(home.getClickSave());
	    Thread.sleep(7000);
	  //  Reports.logStep(LogStatus.INFO, "Waiting for 7 secs", "Waited successfully", false);
	    //click(home.getClickSaveOK());
	    Thread.sleep(7000);
	   // Reports.logStep(LogStatus.INFO, "Waiting for 7 secs", "Waited successfully", false);
	}

	@When("^Click on Submit button$")
	public void click_on_Submit_button() throws Throwable {
	    click_1(home.getClickSubmit());
	    Thread.sleep(7000);
	  //  Reports.logStep(LogStatus.INFO, "Waiting for 7 secs", "Waited successfully", false);
	    click_2(home.getClickSubmitYes());
	    Thread.sleep(7000);
	 //   Reports.logStep(LogStatus.INFO, "Waiting for 7 secs", "Waited successfully", false);
	    //click(home.getClickSaveOK());
	    Thread.sleep(5000);
	  //  Reports.logStep(LogStatus.INFO, "Waiting for 5 secs", "Waited successfully", false);
	}



}
