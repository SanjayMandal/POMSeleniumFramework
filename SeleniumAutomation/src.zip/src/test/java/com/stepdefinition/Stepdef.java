package com.stepdefinition;

import com.ObjectRepository.JetBlueHomePage;
import com.ObjectRepository.JetBlueLoginPage;
import com.resources.FunctionalLibrary;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.sql.SQLException;

import org.testng.Assert;

public class Stepdef extends FunctionalLibrary {
	
	private static JetBlueHomePage home = null;
	private static JetBlueLoginPage login = null;
	private Scenario scenario;
	
	@Before
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	}
	
	@After
	public void after(Scenario scenario) throws SQLException, ClassNotFoundException{
		createDBConnection(scenario.getName(), scenario.getStatus());
	}
	
	@Given("^I am on the Jetblue application homepage$")
	public void launch_jetblue_Website_and() throws Throwable {
		home = new JetBlueHomePage();
		jsWaitForPageLoad();
		navigateToUrl("https://www.jetblue.com/");
		jsWaitForPageLoad();
	}
	
	@When("^I enter the credentials \"([^\"]*)\" and \"([^\"]*)\"$")
	public void giving_credentials_as_and(String email, String password) throws Throwable {
		home = new JetBlueHomePage();
		login = new JetBlueLoginPage();
		Thread.sleep(15000);
		click(home.getSignInLink());
		jsWaitForPageLoad();
		Thread.sleep(3000);
		setText(login.getUserNameTextField(),email);
		Thread.sleep(1000);
		setText(login.getPasswordTextField(),password);
		Thread.sleep(5000);
		click(login.getSignInButton());
		jsWaitForPageLoad();
		Thread.sleep(3000);
	}
	
	@Then("^I should see the user logged in$")
	public void user_should_be_logged_in() throws Throwable {
		waitForElementVisibility(home.getSignOutLink());
		Assert.assertTrue(home.getSignOutLink().isDisplayed());
	}

	/*@When("^I choose Travel Information link$")
	public void click_on_Travel_Information_tab() throws Throwable {
		home = new JetBlueHomePage();
		click(home.getTravelInformationLink());
		WaitForPageLoad();
	}
	
	@Then("^I should see the travel informations$")
	public void the_travel_informations_should_be_listed() throws Throwable {
		Assert.assertTrue(getElement("baggage_XPATH","travelInfo").isDisplayed());
		Assert.assertTrue(getElement("cancelAndDelay_XPATH","travelInfo").isDisplayed());
		Assert.assertTrue(getElement("specialAss_XPATH","travelInfo").isDisplayed());
		Assert.assertTrue(getElement("kids_XPATH","travelInfo").isDisplayed());
		Assert.assertTrue(getElement("airport_XPATH","travelInfo").isDisplayed());
		Assert.assertTrue(getElement("homeSweet_XPATH","travelInfo").isDisplayed());
		closeBrowser();
	}*/
}
