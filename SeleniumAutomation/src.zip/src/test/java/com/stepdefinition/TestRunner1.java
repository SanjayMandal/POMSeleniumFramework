package com.stepdefinition;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.resources.FunctionalLibrary;
import com.resources.Reports;

import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.testng.TestNGCucumberRunner;

@CucumberOptions(features = { "src/test/resources/com/Oracle_Fusion.feature"},
				tags={})

public class TestRunner1 extends Reports {
	private Scenario scenario;
	
	@BeforeSuite
	public void initializeReport()
	{
		Initialize();
	}
	
	@Before
	public void startReport( Scenario scenario){
		this.scenario =scenario;
		test =startTest(scenario.getName(),"Test started");
		
	}
	
	@After
	public void endReport( Scenario scenario){
		this.scenario =scenario;
		close();
	}
	
	@Parameters( {"browser"} )
	@BeforeTest
	public void beforeTest(String browser) {
		FunctionalLibrary.driverInit(browser);
		
	}

	@Test
	public void runCukes() {
		new TestNGCucumberRunner(getClass()).runCukes();
	}

	@AfterTest
	public void afterTest() {
		FunctionalLibrary.closeBrowser();
	}
}
